export default function NoPortfolio() {
    return (
        <div className="flex justify-center w-screen pt-10">No portfolio data available</div>
    )
}