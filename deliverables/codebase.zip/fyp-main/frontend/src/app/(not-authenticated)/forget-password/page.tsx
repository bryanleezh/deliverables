export default function ForgetPassword() {
    return (
        <>
            Forget Password
        </>
    )
}